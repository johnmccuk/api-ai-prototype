#!/usr/bin/env python
# import sys
# import logging
import json

'''
Put any pip installs in the requirements.txt file
'''

# logging.info("Cached code goes here")


def lambda_handler(event, context):
    "Endpoint validator and starts Step Function"

    statusCode = 202
    body = {"message": "generation process started"}
    returnBody = body

    if "phrase" not in body:
        statusCode = 422
        returnBody = {"error": "phrase field missing"}

    elif type(body["phrase"]) != "list":
        statusCode = 422
        returnBody = {"error": "phrase field must be a list"}

    elif len(body["phrase"]) < 3:
        statusCode = 422
        returnBody = {"error": "phrase field must contain at least 3 phrases"}

    return {
        "statusCode": statusCode,
        "body": json.dumps(returnBody),
        "headers": {
            "Content-Type": "application/json"
        }
    }
