#!/usr/bin/env python
import json
import os


def lambda_handler(event, context):
    "Save the passed data to an S3 bucket"

    print(context)
    return True
