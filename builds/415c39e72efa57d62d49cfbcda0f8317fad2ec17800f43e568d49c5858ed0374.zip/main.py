#!/usr/bin/env python
import json
import os
import boto3

s3 = boto3.resource('s3')


def lambda_handler(event, context):
    "Save the passed data to an S3 bucket"

    fp = open('/tmp/text.tf', 'w')
    fp.write(event['choices'][0]['text'])
    fp.close()

    s3 = boto3.resource('s3')

    s3.Bucket(os.environ["BUCKET"]).upload_file('/tmp/text.tf', 'text.tf')

    return True
