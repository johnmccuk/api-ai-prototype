#!/usr/bin/env python
import json
import os
import boto3

s3 = boto3.resource('s3')


def lambda_handler(event, context):
    "Save the passed data to an S3 bucket"

    fp = open('text.tf', 'w')
    fp.write(event[0]['choices']['text'])
    fp.close()

    s3 = boto3.resource('s3')

    s3.Bucket('bucketname').upload_file('text.tf', 'text.tf')

    return True
