#!/usr/bin/env python
import json
import os
from urllib import request, parse


def lambda_handler(event, context):
    "Call the open AI endpoint to generate text"

    print(event)
    url = "https://api.openai.com/v1/images/generations"
    key = os.environ["OPEN_AI_KEY"]
    org = os.environ["OPEN_AI_ORG"]
    imageCount = 3
    promptText = ""
    imageSize = "256x256"

    body = {
        "prompt": promptText,
        "n": imageCount,
        "size": imageSize
    }

    data = parse.urlencode(body).encode()
    req = request.Request(url, data=data)
    req.add_header("OpenAI-Organization", org)
    req.add_header("Authorization", "Bearer " + key)
    res = json.loads(request.urlopen(req).read())

    print(res)
    return json.loads(res)
