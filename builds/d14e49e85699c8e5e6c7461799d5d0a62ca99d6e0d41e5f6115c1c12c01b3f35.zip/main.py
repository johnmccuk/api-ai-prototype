#!/usr/bin/env python
import json
import os
from urllib import request, parse


def lambda_handler(event, context):
    "Call the open AI endpoint to generate text"

    print(event)
    url = "https://api.openai.com/v1/completions"
    key = os.environ["OPEN_AI_KEY"]
    org = os.environ["OPEN_AI_ORG"]
    model = os.environ["OPEN_AI_TEXT_MODEL"]

    body = {
        "model": model,
        "prompt": "write me a resignation letter",
        "temperature": 0,
        "max_tokens": 2000
    }

    # data = parse.urlencode(body).encode()
    req = request.Request(url, method="POST", data=json.dumps(body))
    req.add_header("OpenAI-Organization", org)
    req.add_header("Authorization", "Bearer " + key)
    req.add_header("Content-Type", "application/json")
    res = json.loads(request.urlopen(req).read())

    print(res)
    return json.loads(res)
