#!/usr/bin/env python
import json
import os
from urllib import request, parse


def lambda_handler(event, context):
    "Call the open AI endpoint to generate text"

    print(event)

    url = "https://api.openai.com/v1/completions"
    key = os.environ["OPEN_AI_KEY"]
    org = os.environ["OPEN_AI_ORG"]
    model = os.environ["OPEN_AI_TEXT_MODEL"]

    psuedoCode = "create a terraform file to create a " + event['description']

    body = {
        "model": model,
        "prompt": psuedoCode,
        "temperature": 0,
        "max_tokens": 4000 - len(psuedoCode)
    }

    print(body)
    data = json.dumps(body)
    data = data.encode()
    # data = parse.urlencode(body).encode()
    print(data)
    req = request.Request(url, method="POST", data=data)
    req.add_header("OpenAI-Organization", org)
    req.add_header("Authorization", "Bearer " + key)
    req.add_header("Content-Type", "application/json")
    res = json.loads(request.urlopen(req).read())

    print(res)
    return json.load(res)
