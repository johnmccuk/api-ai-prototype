#!/usr/bin/env python
import sys
import logging

'''
Put any pip installs in the requirements.txt file
'''

logging.info("Cached code goes here")


def handler(event, context):
    "Demo Lambda"
    print(event)
    return True
